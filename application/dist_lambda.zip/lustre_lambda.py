# https://github.com/usui-tk/amazon-ec2-update-ami/blob/master/Reference_AWSSupport-CheckAndMountEFS/AWSSupport-CheckAndMountEFS.json
# https://docs.aws.amazon.com/systems-manager-automation-runbooks/latest/userguide/automation-awssupport-check-and-mount-efs.html
# https://docs.aws.amazon.com/fsx/latest/LustreGuide/working-with-ec2-spot-instances.html
# https://developerck.com/running-shell-script-on-ec2-using-api-gateway-aws/
# https://docs.aws.amazon.com/systems-manager-automation-runbooks/latest/userguide/automation-awssupport-check-and-mount-efs.html
